export type WordDAO = {
  
  GUID: String,
  english: String,
  german: String,
  spanish: String,
  french: String,
  
}